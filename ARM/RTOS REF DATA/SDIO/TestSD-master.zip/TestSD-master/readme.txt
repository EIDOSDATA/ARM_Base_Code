Tue 14 Apr 2020 07:08:25 PM MSK

    создал проект с 0
    выбрал плату ...Discovery

    git init

git add -A
iva@IvaUbuntu:~/prog/ARM/STM/TestSD$ git status
On branch master

No commits yet

Changes to be committed:
  (use "git rm --cached <file>..." to unstage)

    new file:   .cproject
    new file:   .mxproject
    new file:   .project
    new file:   .settings/language.settings.xml
    new file:   Core/Inc/main.h
    new file:   Core/Inc/stm32f3xx_hal_conf.h
    new file:   Core/Inc/stm32f3xx_it.h
    new file:   Core/Src/main.c
    new file:   Core/Src/stm32f3xx_hal_msp.c
    new file:   Core/Src/stm32f3xx_it.c
    new file:   Core/Src/syscalls.c
    new file:   Core/Src/sysmem.c
    new file:   Core/Src/system_stm32f3xx.c
    new file:   Core/Startup/startup_stm32f303vctx.s
    new file:   Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xc.h
    new file:   Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h
    new file:   Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h
    new file:   Drivers/CMSIS/Include/cmsis_armcc.h
    new file:   Drivers/CMSIS/Include/cmsis_armclang.h
    new file:   Drivers/CMSIS/Include/cmsis_compiler.h
    new file:   Drivers/CMSIS/Include/cmsis_gcc.h
    new file:   Drivers/CMSIS/Include/cmsis_iccarm.h
    new file:   Drivers/CMSIS/Include/cmsis_version.h
    new file:   Drivers/CMSIS/Include/core_armv8mbl.h
    new file:   Drivers/CMSIS/Include/core_armv8mml.h
    new file:   Drivers/CMSIS/Include/core_cm0.h
    new file:   Drivers/CMSIS/Include/core_cm0plus.h
    new file:   Drivers/CMSIS/Include/core_cm1.h
    new file:   Drivers/CMSIS/Include/core_cm23.h
    new file:   Drivers/CMSIS/Include/core_cm3.h
    new file:   Drivers/CMSIS/Include/core_cm33.h
    new file:   Drivers/CMSIS/Include/core_cm4.h
    new file:   Drivers/CMSIS/Include/core_cm7.h
    new file:   Drivers/CMSIS/Include/core_sc000.h
    new file:   Drivers/CMSIS/Include/core_sc300.h
    new file:   Drivers/CMSIS/Include/mpu_armv7.h
    new file:   Drivers/CMSIS/Include/mpu_armv8.h
    new file:   Drivers/CMSIS/Include/tz_context.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pcd_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_spi.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_spi_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_tim_ex.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_ll_usb.h
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pcd.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pcd_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_spi.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_spi_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_tim.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_tim_ex.c
    new file:   Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usb.c
    new file:   STM32F303VCTX_FLASH.ld
    new file:   TestSD.ioc
    new file:   readme.txt

git commit -m "initial state"

    STM32CubeMX - TestSD.ioc - Pinout&Configuration
	Middleware - FREERTOS 
	    Mode - Interface=CMSIS_V2
	    Configuration - Config Parameters
		TOTAL_HEAP_SIZE=8000
	Middleware - FATFS
	    Mode - User Defined

    при сохранении получил окно WARNINGS:
- When FreeRTOS is used? it is strogly recommended to use a HAL timebase source other than the Systick...

    STM32CubeMX - TestSD.ioc - Pinout&Configuration
	System Core - SYS
	    Timebase Source=TIM1

git add -A
git commit -m "добавлены FREERTOS, FATFS"
[master 15328b8] добавлены FREERTOS, FATFS
 56 files changed, 35621 insertions(+), 94 deletions(-)
...

    STM32CubeMX - TestSD.ioc - Pinout&Configuration
	Connectivity - SPI2
	    Mode=Full-Duplex Master


Wed 15 Apr 2020 04:16:16 PM MSK
    добавил мигание LED5
    compile - load - debug = OK

git add -A
    добавилось много ненужных файлов
git reset HEAD
    скопировал .gitignore из пред.проекта

Thu 16 Apr 2020 02:04:02 PM MSK
    поменял прескалер=16 ==> BaudRate=1.5 Mb/s

Sat 18 Apr 2020 03:22:01 PM MSK
    добавил задачи Обработка нажатия клавиши и Тестирование SPI
    добавил EventFlags с одним флагом - выполнить тест SPI = EF_SPI_SEND_TEST_CMD
    добавил диагностику создания EventFlags - частотой мигания LD4 (если часто - ошибка)
    по нажатию кнопки гашу индицирующие LD7 LD8
    по отпусканию кнопки ставлю в spi_event_flags флаг EF_SPI_SEND_TEST_CMD,
	а по нему в другой задаче делаю HAL_SPI_TransmitReceive
    соединяю проводом ноги PB14 - PB15
	и посылаю 0,1,2... в SPI2 и тут же принимаю 
	сравниваю - если == - зажигаю LD8
    РАБОТАЕТ!!! Но до 16ти нажатий - дальше несовпадение, т.к. Data Size = 4 Bits

Mon 20 Apr 2020 04:52:43 PM MSK
    отрихтовал под себя FATFS/Target/ffconf.h
    взял из stm32_vs1053_player/CubeIDE/
	user_diskio.c
	fatfs_sd.c & .h

Wed 22 Apr 2020 01:52:29 PM MSK
    за вчера и сегодня 
	- поправил взятые файлы под RTOS (частично - надо потом все проверять и еще править)
	- переписал main.c - по нажатию кнопки выполняется инициализация SD-card и по ее результату зажигается 1 из 3х LED
	- поправил настройки SPI in STM32CubeIDE по примеру из http://mycontroller.ru/old_site/stm32-sd-card-podklyuchenie/#more-1325
	- поправил настройки выхода SD_CS по совету Сонина
	- добавил длинный системный таймер - чтобы задержки в fatfs_sd.c не опрокидывались через 49 дней
ИТОГО:
    карта отвечает правильно!!!!

    начал добавлять работу с FATFS
    ошибки линковки - syscall.c использует функции старой CMSIS-RTOS
    взял файл из https://github.com/miniwinwm/BluePillDemo.git
	из /BluePillDemo_FreeRTOS_FatFS/Middlewares/Third_Party/FatFs/src/option/syscall.c
    этот файл, как оказалось, генерится автоматически кубом - и его надо перезаписывать каждый раз после 
	генерации текстов по .ioc !!!!!!!!!!!!!!!
    команда для перезаписи:
cp -f /home/iva/prog/ARM/STM/BluePillDemo/BluePillDemo_FreeRTOS_FatFS/Middlewares/Third_Party/FatFs/src/option/syscall.c /home/iva/prog/ARM/STM/TestSD/Middlewares/Third_Party/FatFs/src/option/


    malloc не работает - errno=ENOMEM Not enough memory - даже если делаю в 
	*.ioc - Project Manager - Project - Min Heap Size = 0x5000 
    заменил за лок.переменную - не хватило стека - Min Stack Size = 0x4000 - ok
ИТОГО:
    работает disk_initialize - инициализация устройства

Sat 25 Apr 2020 03:46:22 PM MSK
    вчера добился работы f_mount - монтирование ФС - и размонтирование
    для этого:
	поправил задержку при записи, чтобы гарантированно был выход в ОС
	нашел расхождение между алгоритмом Chan http://elm-chan.org/docs/mmc/i/sdinit.png
	    и программой --> добавил установку размера блока=512 для моего типа SD=CT_SD2, 
	понял, что ошибка при вызове SD_SendCmd(CMD17, sector) связана с тем, что для моей карточки
	    номер сектора нужно *512 - а в DRESULT SD_disk_read(...) было:
		if (!(CardType & CT_SD2)) sector *= 512;
	    ==> сделал безусловный  пересчет номера блока в номер байта - после этого заработало f_mount

    сегодня
    в f_open Hard Fault - открыл окно Fault Analyzer - ошибка памяти - открыл окно Static Stack Analyzer
	оказалось - функции MakeSdCardJob требуется ~1120 байт стека а выделено всей задаче - 500
    задаче SpiTask увеличил стек до 1200 в Cube
    Save - auto Code Generate - errors - удалил из проекта автоматич сгенеренный файл syscall.c

    стека оказалось опять мало - после вызова f_open Static Stack Analyzer показал, что MakeSdCardJob нужно 2080 байт
	увеличил TOTAL_HEAP_SIZE  с 8000 до 12000, а стек задачи spiTask с 1200 до 2200

    Hard Fault - проследил шагами - что-то не так в osSemaphoreRelease и xQueueGenericSend, к-е вызываются 
	из ff_rel_grant при _FS_REENTRANT
    обнаружил - через Cube FS_REENTRANT сделать Disabled нельзя...
    USE_MKFS=Disabled
    USE_FASTSEEK=Disabled
    FS_LOCK=1
    и все равно нельзя...

    недостатки в используемом мной syscall.c
	- независимо от параметра FS_LOCK ff_cre_syncobj создает семафор на 1 токен

    при внимательном изучении нашел - гадится адрес семафора - и к моменту его освобождения после (успешного!) чтения файла
	в нем лежит мусор

Sun 26 Apr 2020 04:04:11 PM MSK

    еще увеличил кучу - под самую прожорливую задачу
    урезал опции РТОС
    урезал опции РТОС
    fixed Hard Fault on f_gets
    для РТОС сделал семафор через Cube, еще увеличил стек прожорливой задаче, увеличил буфер чтения из файла - все работает, файл прочитан верно

    впервые - и успешно - использовал watchpoint - с его помощью быстро нашел когда гадится адрес семафора 
	это происходит, похоже, из-за того что в функции SD_RxDataBlock читается лишний байт в цикле...
    все исправил - предыдущие не повлиявшие исправления пока не убирал

    поправил - умножаю на 512 номера сектора только для типа карточки с признаком CT_BLOCK

Mon 27 Apr 2020 08:06:52 PM MSK
    начал следующий этап: прога должна после запуска автоматически открывать чистый файл лога на карте и писать в него
	ежесекундно что-нибудь,
	а по нажатию кнопки 
	прекращать запись и читать файл построчно в буфер
    сделал файл Core/Inc/ProjDefs.h - туда занес BOOL & Co
    сделал SdCardJobs.h & c - Data & functions for working with FATFS on SD-card in RTOS
    сделал log_tasked.h & c - Data & functions for logging to text file on SD-card in RTOS
    сделал MainEventFlags.h - там флаг инициализации SD-card & FATFS on it

ИТОГО: по кнопке вызывается иниц-я диска - в 1й раз долго, во 2й и далее - быстро, ибо уже сделано

